module CSCU9T4Practical1 {
	exports com.stir.cscu9t4practical1;

	requires java.desktop;
}