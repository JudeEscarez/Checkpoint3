/**
 * Author: Jude Escarez
 * BSc Computing Science
 * Checkpoint 3
 */
// An implementation of a Training Record as an ArrayList
package com.stir.cscu9t4practical1;
import java.util.*;

public class TrainingRecord {
    private List<Entry> tr;
    private List<SwimEntry> swtr;
    private List<SprintEntry> sptr;
    private List<CycleEntry> cetr;
    
    public TrainingRecord() {
        tr = new ArrayList<Entry>();
        swtr = new ArrayList<SwimEntry>();
        sptr = new ArrayList<SprintEntry>();
        cetr = new ArrayList<CycleEntry>();
    } //constructor
   public void addEntry(Entry e){
       tr.add(e);    
   } // addEntryClass
   
   public void addCycleEntry(CycleEntry e){
       cetr.add(e);
       tr.add(e);
   }// addCycleEntryClass
   
   public void addSprintEntry(SprintEntry e){
       sptr.add(e);
       tr.add(e);
   }// addSprintEntryClass
   
   public void addSwimEntry(SwimEntry e){
       swtr.add(e);
       tr.add(e);
   }// addSwimEntryClass
   
   /**
    * Create a method to remove the given string Entry of the user
    * @param e String Input or the entry of the user
    * @param d Integer input of the user for the day
    * @param m Integer input of the user for the month
    * @param y Integer input of the user for the year
    * @return String result
    */
   public String removeEnrty(String e, int d, int m, int y){
       String result = "Entry does not match any existing record.";
       ListIterator<CycleEntry> CycleI = cetr.listIterator();
       ListIterator<SprintEntry> SprintI = sptr.listIterator();
       ListIterator<SwimEntry> SwimI = swtr.listIterator();
       if(CycleI.hasNext()){
           CycleEntry current = CycleI.next();
		   if(current.getName().toLowerCase().equals(e.toLowerCase()) && current.getDay() == d
				   && current.getMonth() == m && current.getYear() == y)
		   {
			   tr.remove(current);
			   cetr.remove(current);
			   return "Record on Cycle Entry has been removed.";
		   }
       } else if (SprintI.hasNext()) {
           SprintEntry current = SprintI.next();
		   if(current.getName().toLowerCase().equals(e.toLowerCase()) && current.getDay() == d
				   && current.getMonth() == m && current.getYear() == y)
		   {
			   tr.remove(current);
			   sptr.remove(current);
			   return "Record on Sprint Entry has been removed.";
		   }
        } else if (SwimI.hasNext()){
            SwimEntry current = SwimI.next();
		   if(current.getName().toLowerCase().equals(e.toLowerCase()) && current.getDay() == d
				   && current.getMonth() == m && current.getYear() == y)
		   {
			   tr.remove(current);
			   swtr.remove(current);
			   return "Record on Swim Entry has been removed.";
		   }
        }
       return result;
   }
   // look up the entry of a given day and month
   public String lookupEntry (int d, int m, int y) {
	   ListIterator<Entry> iter = tr.listIterator();
	    StringBuilder resultBuilder = new StringBuilder();
	    boolean foundEntries = false;
	    while (iter.hasNext()) {
	        Entry current = iter.next();
	        if (current.getDay() == d && current.getMonth() == m && current.getYear() == y) {
	            resultBuilder.append(current.getEntry()).append("\n");
	            foundEntries = true;
	        }
	    }
	    if (!foundEntries) {
	        return "No entries found";
	    }
	    return resultBuilder.toString();
   } // lookupEntry
   
   
   // Count the number of entries
   public int getNumberOfEntries(){
       return tr.size();
   }
   // Clear all entries
   public void clearAllEntries(){
       tr.clear();
   }

    private boolean While(boolean hasNext) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
   
} // TrainingRecord