/**
 * Author: Jude Escarez
 * BSc Computing Science
 * Checkpoint 3
 */
package com.stir.cscu9t4practical1;

public class CycleEntry extends Entry{
	private String terrain;
	private String tempo;
	public CycleEntry(String n, int d, int m, int y, int h, int min, int s, float dist, String terrain, String tempo) {
		super(n, d, m, y, h, min, s, dist);
		this.terrain = terrain;
		this.tempo = tempo;
	}
	public String getTerrain() {
		if(terrain.equalsIgnoreCase("Mountain"))
			return  terrain;
		else if(terrain.equalsIgnoreCase("Asphalt"))
			return terrain;
		else
		return terrain;
	}
	public void setTerrain(String terrain) {
		this.terrain = terrain;
	}
	public String getTempo() {
		if(tempo.equalsIgnoreCase("Fast"))
			return tempo;
		else if(tempo.equalsIgnoreCase("Moderate"))
			return tempo;
		else
		return tempo;
	}
	public void setTempo(String tempo) {
		this.tempo = tempo;
	}
	public String getEntry () {
		   String result = getName()+" ran " + getDistance() + " km in "
		             +getHour()+":"+getMin()+":"+ getSec() + " on "
		             +getDay()+"/"+getMonth()+"/"+getYear()+ " on " 
		             + getTerrain() + " at " + getTempo() +  "tempo\n";
		   return result;
		  } //getEntry
}
