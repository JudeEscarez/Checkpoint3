package com.stir.cscu9t4practical1;

public class SprintEntry extends Entry {
	private int round;
	private int recoveryTime;
	
	public SprintEntry(String n, int d, int m, int y, int h, int min, int s, float dist, int round, int recoveryTime) {
		super(n, d, m, y, h, min, s, dist);
		this.round = round;
		this.recoveryTime = recoveryTime;
	}
	public int getRound() {
		return round;
	}
	public void setRound(int round) {
		this.round = round;
	}
	public int getRecoveryTime() {
		return recoveryTime;
	}
	public void setRecoveryTime(int recoveryTime) {
		this.recoveryTime = recoveryTime;
	}
	public String getEntry () {
		   String result = getName()+" ran " + getDistance() + " km in "
		             +getHour()+":"+getMin()+":"+ getSec() + " on "
		             +getDay()+"/"+getMonth()+"/"+getYear()
		             +getRound() + getRecoveryTime() +"\n";
		   return result;
		  } //getEntry
}
