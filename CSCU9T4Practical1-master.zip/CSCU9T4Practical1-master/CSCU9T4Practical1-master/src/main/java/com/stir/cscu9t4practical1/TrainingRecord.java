// An implementation of a Training Record as an ArrayList
package com.stir.cscu9t4practical1;




import java.util.*;


public class TrainingRecord {
    private List<Entry> tr;
    private List<SwimEntry> swtr;
    private List<SprintEntry> sptr;
    private List<CycleEntry> cetr;
    
    public TrainingRecord() {
        tr = new ArrayList<Entry>();
        swtr = new ArrayList<SwimEntry>();
        sptr = new ArrayList<SprintEntry>();
        cetr = new ArrayList<CycleEntry>();
        
    } //constructor
    
    // add a record to the list
   public void addEntry(Entry e){
       tr.add(e);    
   } // addClass
   
   // look up the entry of a given day and month
   public String lookupEntry (int d, int m, int y) {
	   ListIterator<Entry> iter = tr.listIterator();
	    StringBuilder resultBuilder = new StringBuilder();
	    boolean foundEntries = false;
	    while (iter.hasNext()) {
	        Entry current = iter.next();
	        if (current.getDay() == d && current.getMonth() == m && current.getYear() == y) {
	            resultBuilder.append(current.getEntry()).append("\n");
	            foundEntries = true;
	        }
	    }
	    if (!foundEntries) {
	        return "No entries found";
	    }
	    return resultBuilder.toString();
   } // lookupEntry
   
   
   // Count the number of entries
   public int getNumberOfEntries(){
       return tr.size();
   }
   // Clear all entries
   public void clearAllEntries(){
       tr.clear();
   }
   
} // TrainingRecord